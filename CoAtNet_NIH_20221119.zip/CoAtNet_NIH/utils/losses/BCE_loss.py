import torch
from torch import nn
import torch.nn.functional as F

class BinaryCELoss(nn.Module):
    def __init__(self, weight=None, size_average=None, reduce=None, reduction='mean'):
        super(BinaryCELoss, self).__init__()
        self.loss = nn.BCELoss(weight, size_average, reduce, reduction)
    def forward(self, logits, targets):
        assert logits.shape == targets.shape
        
        loss = self.loss(torch.sigmoid(logits), targets)

        return loss