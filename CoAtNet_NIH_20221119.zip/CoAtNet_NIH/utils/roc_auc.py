from sklearn.metrics import roc_auc_score, roc_curve, accuracy_score
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
import numpy as np

def roc_auc(labels, outputs):
    '''
    labels: [N,], gt_class_id, tensor
    outputs: [N,], class prob, tensor
    '''
    return
    
if __name__ == '__main__':
    X, y = load_iris(return_X_y=True)
    clf = LogisticRegression(solver="liblinear").fit(X, y)
    pred = clf.predict_proba(X)
    print(roc_auc_score(y, pred, multi_class='ovr'))
    label_pred = np.argmax(pred, axis=-1)
    print(accuracy_score(y, label_pred))
    