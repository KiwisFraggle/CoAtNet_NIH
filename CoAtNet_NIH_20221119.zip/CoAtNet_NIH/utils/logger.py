#!/usr/bin/env python
#-*- coding:utf-8 -*-
# @Time    : 2021/4/13 15:42
# @Author  : Yue
import time
import os
import logging
def create_logger(args, cfg_name, out_path, phase='train'):

    if not os.path.exists(out_path):
        print('=> creating {}'.format(out_path))
        os.mkdir(out_path)

    # final_output_dir = os.path.join(out_path, cfg_name)
    final_output_dir = out_path
    if not os.path.exists(final_output_dir) and phase=='train':
        print('=> creating {}'.format(final_output_dir))
        os.mkdir(final_output_dir)

    time_str = time.strftime('%Y-%m-%d-%H-%M')
    log_file = '{}_{}_{}.log'.format(cfg_name, time_str, phase)
    final_log_file = os.path.join(final_output_dir, log_file)
    head = '%(asctime)-15s %(message)s'
    logging.basicConfig(filename=str(final_log_file),
                        format=head)
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    console = logging.StreamHandler()
    logging.getLogger('').addHandler(console)

    tensorboard_log_dir = os.path.join(final_output_dir, cfg_name + '_' + time_str)
    # if args.local_rank == 0:
    if not os.path.exists(tensorboard_log_dir) and phase=='train':
        logging.info('=> creating {}'.format(tensorboard_log_dir))
        os.makedirs(tensorboard_log_dir)

    return logger, final_output_dir, tensorboard_log_dir

def create_logger_distribute(args, cfg_name, out_path, phase='train'):

    if not os.path.exists(out_path):
        print('=> creating {}'.format(out_path))
        os.mkdir(out_path)

    # final_output_dir = os.path.join(out_path, cfg_name)
    final_output_dir = out_path
    if not os.path.exists(final_output_dir) and phase=='train':
        print('=> creating {}'.format(final_output_dir))
        os.mkdir(final_output_dir)

    time_str = time.strftime('%Y-%m-%d-%H-%M')
    log_file = '{}_{}_{}.log'.format(cfg_name, time_str, phase)
    final_log_file = os.path.join(final_output_dir, log_file)
    head = '%(asctime)-15s %(message)s'
    logging.basicConfig(filename=str(final_log_file),
                        format=head)
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    console = logging.StreamHandler()
    logging.getLogger('').addHandler(console)

    tensorboard_log_dir = os.path.join(final_output_dir, cfg_name + '_' + time_str)
    if args.local_rank == 0:
        if not os.path.exists(tensorboard_log_dir) and phase=='train':
            logging.info('=> creating {}'.format(tensorboard_log_dir))
            os.makedirs(tensorboard_log_dir)

    return logger, final_output_dir, tensorboard_log_dir
