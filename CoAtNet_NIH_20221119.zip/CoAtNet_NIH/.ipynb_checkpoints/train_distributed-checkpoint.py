from functools import partial
import os
import argparse
import yaml
import time

from random import randint, choices
import random
from datetime import datetime
from math import log2

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import copy
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data.distributed import DistributedSampler

import torchvision
from torchvision import datasets, models, transforms
from torchvision.transforms import AutoAugmentPolicy, AutoAugment
from torchvision.models import resnet50, vit_b_16, efficientnet_b0, efficientnet_b5

from tensorboardX import SummaryWriter

from utils.utils import dict2namespace, read_config, set_seed, get_last_modified, set_seed_all, add_weight_decay, CutoutPIL
from utils.logger import create_logger_distribute
from utils import tb_utils
from dataloader.data_loader import YamlLoader
from model.coatnet import CoAtNet, coatnet_0
from model.custom_resnet import custom_resnet50
from model.ema import ModelEma
from timm.models.maxxvit import coatnet_0_rw_224, coatnet_bn_0_rw_224, coatnet_0_224
from transformers import optimization

from utils.losses import BinaryFocalLoss, BinaryCELoss, MultilabelFocalLoss, MultilabelDiceLoss, AsymmetricLoss, WeightedAsymmetricLoss
from utils.losses.resample_loss import default_resample_loss

from torch.cuda.amp import GradScaler, autocast
from torchvision.ops.misc import ConvNormActivation, SqueezeExcitation


def train(cfg, num_epochs, image_dataloader, model, criterion, optimizer, scheduler, writer, logger, device, model_name='CoAtNet'):
    dataset_sizes = cfg.train.dataloader.dataset_sizes
    last_loss = 100
    patience = cfg.train.optimizer.patience
    early_stopping = cfg.train.optimizer.early_stopping
    model_name = cfg.train.model.model_name
    trigger_times = 0

    total_start = time.time()

    total_train_accuracy = []
    total_train_loss = []
    total_val_accuracy = []
    total_val_loss = []

    best_model_weight = copy.deepcopy(model.state_dict())
    best_acc = 0.0
    best_loss = float('inf')

    last_epoch = cfg.train.last_epoch
    for epoch in range(last_epoch, num_epochs):
        start = time.time()
        logger.info('Epoch {} / {}'.format(epoch, num_epochs-1))
        logger.info('-' * 20)
        
        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()
            else:
                model.eval()
            
            running_loss = 0.0
            running_corrects = 0

            total_data = 0
            #for inputs, labels in tqdm(image_dataloader[phase]):
            for index, (inputs, labels, file_name) in enumerate(tqdm(image_dataloader[phase])):
                inputs, labels = inputs.to(device).float(), labels.to(device).float()

                optimizer.zero_grad()

                if phase == 'train':
                    outputs = model(inputs)
                else:
                    with torch.no_grad():
                        outputs = model(inputs)    
                _, preds = torch.max(outputs, 1)
                loss = criterion(outputs, labels)

                if phase == 'train':
                    loss.backward()
                    optimizer.step()
                    
                    lr = optimizer.param_groups[0]['lr']
                    if cfg.train.local_rank == 0:
                        tb_utils.iter_scalar_metrics(writer, 'lr', lr, epoch * len(image_dataloader[phase]) + index)
                
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)
                total_data += inputs.shape[0]

            if phase == 'train':
                scheduler.step()
            
            epoch_loss = running_loss / total_data
            epoch_accuracy = running_corrects.float() / total_data

            if phase == 'train':
                total_train_loss.append(epoch_loss)
                total_train_accuracy.append(epoch_accuracy)
            if phase == 'val':
                total_val_loss.append(epoch_loss)
                total_val_accuracy.append(epoch_accuracy)

            logger.info('{} Loss: {:.5f} Accuracy: {:.5f}'.format(phase, epoch_loss, epoch_accuracy))

            if phase == 'val' and epoch_accuracy > best_acc:
                best_acc = epoch_accuracy
                best_loss = epoch_loss
                best_model_weight = copy.deepcopy(model.state_dict())

            if early_stopping and phase == 'val':
                if last_loss < epoch_loss:
                    trigger_times += 1
                    if trigger_times >= patience:
                        logger.info('Early stopping at epoch {}'.format(epoch))
                        total_time_elapsed = np.round(time.time() - total_start, 3)
                        logger.info('Completed training in {:0f}m {:03f}s'.format(total_time_elapsed // 60, total_time_elapsed % 60))
                        logger.info('Best Accuracy: {}, Best Loss: {}'.format(best_acc, best_loss))
                        model.load_state_dict(best_model_weight)
                        return model, total_train_accuracy, total_train_loss, total_val_accuracy, total_val_loss
                else:
                    trigger_times = 0
                last_loss = epoch_loss
        
        loss_dict = {
            "train": total_train_loss[-1],
            "val": total_val_loss[-1]
        }
        acc_dict = {
            "train": total_train_accuracy[-1],
            "val": total_val_accuracy[-1]
        }
        if cfg.train.local_rank == 0:
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/loss', loss_dict, epoch)
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/acc', acc_dict, epoch)

        #save on every 10 epochs
        if epoch % cfg.train.optimizer.save_frequency == 0 and cfg.train.local_rank == 0:
            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': criterion,
                'epoch': epoch
            }, os.path.join(cfg.train.optimizer.save_path, '{}_epoch_{}.pt'.format(model_name, epoch)))
            
        end = np.round(time.time() - start, 3)
        logger.info('Epoch {}: {}s\n'.format(epoch, end))

    total_time_elapsed = np.round(time.time() - total_start, 3)
    logger.info('Completed training in {:0f}m {:03f}s'.format(total_time_elapsed // 60, total_time_elapsed % 60))
    logger.info('Best Accuracy: {}, Best Loss: {}'.format(best_acc, best_loss))

    model.load_state_dict(best_model_weight)
    return model, total_train_accuracy, total_train_loss, total_val_accuracy, total_val_loss

def train_multilabel(cfg, num_epochs, image_dataloader, model, criterion, optimizer, scheduler, writer, logger, device, early_stopping=True, model_name='CoAtNet'):
    last_loss = 100
    patience = cfg.train.optimizer.patience
    trigger_times = 0

    model_name = cfg.train.model.model_name

    early_stopping = cfg.train.optimizer.early_stopping
    dataset_sizes = cfg.train.dataloader.dataset_sizes

    total_start = time.time()

    total_train_accuracy = []
    total_train_loss = []
    total_val_accuracy = []
    total_val_loss = []
    total_train_ce = []
    total_val_ce = []
    total_train_L1 = []
    total_val_L1 = []
    total_train_positive_accuracy = []
    total_val_positive_accuracy = []
    total_train_negative_accuracy = []
    total_val_negative_accuracy = []    

    best_model_weight = copy.deepcopy(model.state_dict())
    best_acc = 0.0
    best_loss = float('inf')

    last_epoch = cfg.train.last_epoch

    ema = ModelEma(model, 0.9997)
    scaler = GradScaler()
    # ce_func = nn.CrossEntropyLoss()

    pos_weight = torch.FloatTensor(cfg.train.dataloader.pos_weight).cuda()
    ce_func = nn.BCEWithLogitsLoss(pos_weight=pos_weight, reduction='mean')

    for epoch in range(last_epoch, num_epochs):
        if epoch == cfg.train.optimizer.warm_up:
            for (name, param) in model.named_parameters():
                param.requires_grad = True
        start = time.time()
        logger.info('Epoch {} / {}'.format(epoch, num_epochs-1))
        logger.info('-' * 20)
        
        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()
            else:
                model.eval()
            
            running_loss = 0.0
            running_ce_loss = 0.0
            running_L1_loss = 0.0
            running_corrects = 0
            total_data = 0
            total_labels = 0
            positive_corrects = 0
            negative_corrects = 0
            positive_labels = 0
            negative_labels = 0

            # pos_count = torch.zeros(cfg.train.model.num_classes).cuda()
            
            #for inputs, labels in tqdm(image_dataloader[phase]):
            for index, (inputs, labels, file_name) in enumerate(tqdm(image_dataloader[phase])):
                inputs, labels = inputs.to(device).float(), labels.to(device).float()

                optimizer.zero_grad()

                if phase == 'train':
                    with autocast():
                        outputs = model(inputs).float()
                else:
                    with torch.no_grad():
                        with autocast():
                            outputs = model(inputs).float()
                preds = torch.round(torch.sigmoid(outputs))
                loss = criterion(outputs, labels)
                ce_loss = ce_func(outputs, labels)
                # pos_count += torch.sum(labels, 0)

                regular_loss = 0
                for param in model.module.parameters():
                    regular_loss += torch.sum(torch.abs(param))

                # loss += 0.005 * regular_loss      #ASL
                # loss += 1e-5 * regular_loss        

                if phase == 'train':
                    # loss.backward()
                    # optimizer.step()
                    
                    model.zero_grad()

                    scaler.scale(loss).backward()
                    scaler.step(optimizer)
                    scaler.update()
                    scheduler.step()

                    ema.update(model)

                    lr = optimizer.param_groups[0]['lr']
                    if writer is not None:
                        tb_utils.iter_scalar_metrics(writer, 'lr', lr, epoch * len(image_dataloader[phase]) + index)

                SumPN = inputs.shape[0]*labels.shape[1]
                T = torch.sum(torch.sum(labels, 1)).item() # 实际正样本数
                P = torch.sum(torch.sum(preds, 1)).item() # 预测正样本数
                TP = torch.sum(torch.sum(labels * preds, 1)).item() # 真阳性样本数
                FN = T-TP # 预测负样本，实际为正样本
                FP = P-TP # 预测正样本，实际为副样本
                F = SumPN-T # 负样本数
                TN = F-FP # 实际副样本数


                total_data += inputs.shape[0]
                total_labels += SumPN
                running_loss += loss.item() * inputs.size(0)
                running_ce_loss += ce_loss.item() * inputs.size(0)
                running_L1_loss += regular_loss.item() * inputs.size(0)
                # running_corrects += torch.sum(torch.sum(torch.eq(preds , labels), 1)/ labels.shape[1]).item()
                running_corrects += torch.sum(torch.eq(preds, labels).all(1))

                # positive_corrects += torch.sum(torch.sum(labels * preds, 1)/ torch.sum(labels, 1)).item()
                positive_corrects += TP
                positive_labels += T             

                negative_corrects += TN
                negative_labels += F

            # print(pos_count.cpu().numpy())
            
            # if phase == 'train':
            #     scheduler.step()
            
            epoch_loss = running_loss / total_data
            epoch_accuracy = running_corrects.float() / total_data
            positive_accuracy = positive_corrects / positive_labels # Positive recall
            negative_accuracy = negative_corrects / negative_labels # Negetive recall
            epoch_ce_loss = running_ce_loss / total_data
            epoch_L1_loss = running_L1_loss / total_data


            if phase == 'train':
                total_train_loss.append(epoch_loss)
                total_train_accuracy.append(epoch_accuracy)
                total_train_positive_accuracy.append(positive_accuracy)
                total_train_negative_accuracy.append(negative_accuracy)
                total_train_ce.append(epoch_ce_loss)
                total_train_L1.append(epoch_L1_loss)
            if phase == 'val':
                total_val_loss.append(epoch_loss)
                total_val_accuracy.append(epoch_accuracy)
                total_val_positive_accuracy.append(positive_accuracy)
                total_val_negative_accuracy.append(negative_accuracy)
                total_val_ce.append(epoch_ce_loss)
                total_val_L1.append(epoch_L1_loss)

            logger.info('{} Loss: {:.5f} Accuracy: {:.5f}, Pos_Acc: {:.5f}, Neg_Acc: {:.5f}, CE: {:.5f}, L1: {:.5f}'.format(phase, epoch_loss, epoch_accuracy, positive_accuracy, negative_accuracy, epoch_ce_loss, epoch_L1_loss))

            # if phase == 'val' and epoch_accuracy > best_acc:
            if phase == 'val' and epoch_loss < best_loss:
                best_acc = epoch_accuracy
                best_pos = positive_corrects
                best_loss = epoch_loss
                best_model_weight = copy.deepcopy(model.state_dict())

            if early_stopping and phase == 'val':
                if last_loss < epoch_loss:
                    trigger_times += 1
                    if trigger_times >= patience:
                        logger.info('Early stopping at epoch {}'.format(epoch))
                        total_time_elapsed = np.round(time.time() - total_start, 3)
                        logger.info('Completed training in {:0f}m {:03f}s'.format(total_time_elapsed // 60, total_time_elapsed % 60))
                        logger.info('Best Accuracy: {}, Best Loss: {}'.format(best_acc, best_loss))
                        model.load_state_dict(best_model_weight)
                        return model, total_train_accuracy, total_train_loss, total_val_accuracy, total_val_loss
                else:
                    trigger_times = 0
                last_loss = epoch_loss
        
        loss_dict = {
            "train": total_train_loss[-1],
            "val": total_val_loss[-1]
        }
        acc_dict = {
            "train": total_train_accuracy[-1],
            "val": total_val_accuracy[-1]
        }
        positive_acc_dict = {
            "train": total_train_positive_accuracy[-1],
            "val": total_val_positive_accuracy[-1]
        }
        negative_acc_dict = {
            "train": total_train_negative_accuracy[-1],
            "val": total_val_negative_accuracy[-1]
        }
        ce_dict = {
            "train": total_train_ce[-1],
            "val": total_val_ce[-1]
        }
        L1_dict = {
            "train": total_train_L1[-1],
            "val": total_val_L1[-1]
        }                
        if writer is not None:
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/loss', loss_dict, epoch)
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/acc', acc_dict, epoch)
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/positive_acc', positive_acc_dict, epoch)
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/negative_acc', negative_acc_dict, epoch)
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/ce', ce_dict, epoch)            
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/L1', L1_dict, epoch)   

        #save on every 10 epochs
        if epoch % cfg.train.optimizer.save_frequency == 0:
            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                # 'loss': criterion,
                'epoch': epoch
            }, os.path.join(cfg.train.optimizer.save_path, '{}_{}_epoch_{}.pt'.format(model_name, cfg.train.dataloader.database, epoch)))

        end = np.round(time.time() - start, 3)
        logger.info('Epoch {}: {}s\n'.format(epoch, end))

    total_time_elapsed = np.round(time.time() - total_start, 3)
    logger.info('Completed training in {:0f}m {:03f}s'.format(total_time_elapsed // 60, total_time_elapsed % 60))
    logger.info('Best Accuracy: {}, Best Loss: {}'.format(best_acc, best_loss))

    model.load_state_dict(best_model_weight)
    return model, total_train_accuracy, total_train_loss, total_val_accuracy, total_val_loss

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="./config/NIH_1000.yaml", type=str)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--local_rank", type=int, default=-1)
    parser.add_argument("--model", type=str, default="CoAtNet")
    args = parser.parse_args()

    cfg = dict2namespace(read_config(args.config))
    args.local_rank = int(os.environ["LOCAL_RANK"])
    cfg.train.local_rank = args.local_rank

    torch.cuda.set_device(args.local_rank)
    device = torch.device('cuda', args.local_rank)
    if torch.distributed.is_nccl_available():
        torch.distributed.init_process_group(backend='nccl')
    else:
        torch.distributed.init_process_group(backend='gloo')
    # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    set_seed_all(cfg.seed)


    #create log
    log_name = args.config.split("/")[-1].split(".yaml")[0]
    log_path = cfg.train.optimizer.log_path
    if(not os.path.exists(log_path)) and args.local_rank == 0:
        os.makedirs(log_path)
    if(not os.path.exists(cfg.train.optimizer.save_path)) and args.local_rank == 0:
        os.makedirs(cfg.train.optimizer.save_path)
    logger, _, tensorboard_dir = create_logger_distribute(args, log_name, log_path)
    
    logger.info(torch.__version__)
    logger.info(torch.cuda.is_available())
    logger.info(cfg)
    logger.info("class_num: {}".format(len(cfg.train.dataloader.labels)))

    ckpt = None
    cfg.train.last_epoch = 0
    if args.resume:
        logger.info("load ckpt...")
        ckpt = get_last_modified(cfg.train.optimizer.save_path)
        map_location = {'cuda:%d' % 0: 'cuda:%d' % args.local_rank}
        ckpt = torch.load(ckpt, map_location=map_location)
        cfg.train.last_epoch = ckpt["epoch"] + 1
        logger.info("load checkpoint from epoch {}".format(ckpt["epoch"]))
    
    #dataloader

    #TODO: general mode without change file dirs
    
    mean = cfg.train.dataloader.normalize.mean
    std = cfg.train.dataloader.normalize.std
    data_transforms = {
    'train': transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.AutoAugment(policy=AutoAugmentPolicy.IMAGENET),
        # transforms.RandomRotation(degrees=10),
        # transforms.RandomAffine(degrees=[-10, 10], translate=[0.1, 0.05], scale=[0.9, 1.1], shear=0.1),
        # transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2)
        # transforms.RandomAdjustSharpness(sharpness_factor=2), 
        # transforms.RandomAutoContrast(), 
        transforms.Resize(cfg.train.dataloader.resize[1:]),
        # CutoutPIL(cutout_factor=0.5),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
        transforms.RandomErasing()
    ]),
    'val': transforms.Compose([
        transforms.Resize(cfg.train.dataloader.resize[1:]),
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ])
}
    data_yaml = {
        'train': cfg.train.dataloader.train_path,
        'val': cfg.train.dataloader.val_path
    }

    image_datasets = {x: YamlLoader(cfg, data_yaml[x], data_transforms[x]) for x in ['train', 'val']}
    image_sampler = {x: DistributedSampler(image_datasets[x]) for x in ['train', 'val']}
    image_dataloader = {x: torch.utils.data.DataLoader(image_datasets[x], \
        batch_size=cfg.train.dataloader.batch_size, \
        num_workers=cfg.train.dataloader.num_workers,
        sampler=image_sampler[x]) \
        for x in ['train', 'val']}

    dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'val']}
    cfg.train.dataloader.dataset_sizes = dataset_sizes

    class_names = image_datasets['train'].classes

    #model
    # model = coatnet_0(cfg.train.model.in_channels, cfg.train.model.num_classes, cfg.train.dataloader.resize[1:])
    # model = coatnet_0_rw_224(pretrained=True, in_chans=cfg.train.model.in_channels, num_classes=cfg.train.model.num_classes, drop_rate=0.5)
    # model = coatnet_bn_0_rw_224(pretrained=True, in_chans=cfg.train.model.in_channels, num_classes=cfg.train.model.num_classes, drop_rate=0.5, drop_path_rate=0.2)

    # model = resnet50(pretrained=True)
    # model.conv1 = nn.Conv2d(cfg.train.model.in_channels, 64, kernel_size=7, stride=2, padding=3,
    #                            bias=False)    
    # model.fc = nn.Sequential(nn.Dropout(0.2), nn.Linear(model.fc.in_features, cfg.train.model.num_classes))

    # not_freeze_dict = ["conv1.weight", "bn1.weight", "bn1.bias", "fc.weight", "fc.bias"]
    # #freeze
    # for (name, param) in model.named_parameters():
    #     if name not in not_freeze_dict:
    #         # print(name)
    #         param.requires_grad = False
    #     else:
    #         pass

    # model = custom_resnet50(cfg.train.model.in_channels, cfg.train.model.num_classes, pretrained=True)

    model = resnet50(pretrained=True)
    model.conv1 = nn.Conv2d(cfg.train.model.in_channels, 64, kernel_size=7, stride=2, padding=3, bias=False)
    model.fc = nn.Sequential(
        nn.Dropout(p=0.5), 
        nn.Linear(model.fc.in_features, cfg.train.model.num_classes))

    # print(model)
    # stat(model, cfg.train.dataloader.resize)
    # total = sum([param.nelement() for param in model.parameters()])
    # print("Number of parameters: %.2fM" % (total/1e6))

    # model = vit_b_16(pretrained=True)
    # model.conv_proj = nn.Conv2d(cfg.train.model.in_channels, 768, kernel_size=(16, 16), stride=(16, 16))
    # model.heads.head = nn.Sequential(
    #     nn.Dropout(p=0.5, inplace=True),
    #     nn.Linear(in_features=768, out_features=cfg.train.model.num_classes, bias=True))

    # model = efficientnet_b5(pretrained=True)
    # model.features[0] = ConvNormActivation(
    #     in_channels=1, 
    #     out_channels=48,
    #     kernel_size=3,
    #     stride=2,
    #     norm_layer=partial(nn.BatchNorm2d, eps=0.001, momentum=0.01),
    #     activation_layer=nn.SiLU)
    # model.classifier = nn.Sequential(
    #     nn.Dropout(p=0.5, inplace=True),
    #     nn.Linear(in_features=2048, out_features=cfg.train.model.num_classes, bias=True))


    model.to(device)
    model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.local_rank], output_device=args.local_rank, find_unused_parameters=False)

    if ckpt is not None:
        model.load_state_dict(ckpt["model_state_dict"])

    #optimizer
    if isinstance(model,torch.nn.DataParallel):
        train_params = model.module.parameters() 
    else:
        train_params = model.parameters()
    weight_decay = 1e-2
    train_params = add_weight_decay(model, weight_decay)
    # optimizer = optim.SGD(train_params, lr=cfg.train.optimizer.lr, momentum=0.9, weight_decay=5)
    optimizer = optim.Adam(train_params, lr=cfg.train.optimizer.lr, weight_decay=0)
    # optimizer = optim.AdamW(train_params, lr=cfg.train.optimizer.lr, weight_decay=500, amsgrad=True)

    if ckpt is not None:
        optimizer.load_state_dict(ckpt["optimizer_state_dict"])
    
    # scheduler = lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)
    # scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, min_lr=0.00001)
    scheduler = lr_scheduler.OneCycleLR(optimizer, 
                                        max_lr=cfg.train.optimizer.lr,
                                        steps_per_epoch=len(image_dataloader['train'])+1,
                                        epochs=cfg.train.optimizer.epochs,
                                        pct_start=0.2)

    # scheduler = optimization.get_cosine_schedule_with_warmup(
    #     optimizer, 
    #     num_warmup_steps=10*len(image_dataloader['train']), 
    #     num_training_steps=cfg.train.optimizer.epochs*len(image_dataloader['train']), 
    #     ) 

    # scheduler = optimization.get_cosine_with_hard_restarts_schedule_with_warmup(
    #     optimizer, 
    #     num_warmup_steps=10*len(image_dataloader['train']), 
    #     num_training_steps=cfg.train.optimizer.epochs*len(image_dataloader['train']), 
    #     num_cycles=3)     

    # pos_weight = torch.FloatTensor(cfg.train.dataloader.pos_weight).cuda()
    # criterion = nn.CrossEntropyLoss()
    # # criterion = MultilabelFocalLoss(gamma=2, alpha=0.1)
    # # criterion = BinaryCELoss()
    # # pos_weight=torch.FloatTensor([1.50, 3.14, 1.71, 4.27, 7.78, 13.75, 7.19, 3.77, 8.75, 1, 11.90, 3.42, 5.87]).to(device)
    # criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight, reduction='mean')
    # criterion = lambda x,y : 0.5*MultilabelDiceLoss()(x, y) + 0.5*nn.BCEWithLogitsLoss(pos_weight=pos_weight)(x, y)
    # criterion = lambda x,y: AsymmetricLoss(gamma_neg=1.5, gamma_pos=0, clip=0.05, disable_torch_grad_focal_loss=True)(x,y) + nn.L1Loss()(x,y)
    # pos_weight = torch.FloatTensor([4.6, 8.7, 7.4, 16.7, 20.2, 18.4, 23.0, 32.1, 39.4, 43.7, 65.5, 47.7, 77.4, 486.9]).cuda()
    # pos_weight = torch.FloatTensor([1.6, 3.5, 2.9, 7.2, 8.7, 7.9, 10.1, 14.3, 17.6, 19.5, 29.6, 21.4, 35.1, 221.6]).cuda()
    # pos_weight = torch.FloatTensor([1.6, 2.9, 8.7, 17.6]).cuda()
    # pos_weight = torch.FloatTensor([1.6, 3.5, 2.9, 7.2, 8.7, 7.9, 17.6, 35.1]).cuda()
    # criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight, reduction='mean')
    # criterion = AsymmetricLoss(gamma_neg=4.0, gamma_pos=1.0, clip=0.05, disable_torch_grad_focal_loss=True)
    # criterion = WAsymmetricLoss(gamma_neg=4.0, gamma_pos=1.0, pos_weight=pos_weight, clip=0.09, disable_torch_grad_focal_loss=True)
    # criterion = lambda x,y: AsymmetricLoss(gamma_neg=2.0, gamma_pos=0, clip=0.2, disable_torch_grad_focal_loss=True)(x,y) + nn.BCEWithLogitsLoss(pos_weight=pos_weight)(x,y)
    # criterion = lambda x,y: 20*AsymmetricLoss(gamma_neg=4.0, gamma_pos=1.0, clip=0.09, disable_torch_grad_focal_loss=True)(x,y) + 0.5*nn.BCEWithLogitsLoss(pos_weight=pos_weight, reduction='mean')(x,y)
    # criterion = lambda x,y: AsymmetricLoss(gamma_neg=3.0, gamma_pos=1.0, clip=0.1, disable_torch_grad_focal_loss=True)(x,y) + nn.BCEWithLogitsLoss()(x,y)
    # criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight, reduction='mean')
    # criterion = lambda x,y: 0.5*AsymmetricLoss(gamma_neg=1.5, gamma_pos=0, clip=0.05, disable_torch_grad_focal_loss=True)(x,y) + 0.5*nn.BCEWithLogitsLoss(pos_weight=pos_weight, reduction='mean')(x,y)
    # criterion = default_resample_loss(cfg)
    # pos_weight = cfg.train.dataloader.pos_ratio
    # criterion =  WeightedAsymmetricLoss(alpha=0.2, gamma_neg=4.0, gamma_pos=1.0, clip=0.05, reduction='sum', pos_weight=pos_weight)
    criterion = nn.BCEWithLogitsLoss()    


    if args.local_rank == 0:
        writer = SummaryWriter(tensorboard_dir)
    else:
        writer = None

    #train
    train_multilabel(cfg, cfg.train.optimizer.epochs, image_dataloader, model, criterion,optimizer, scheduler, writer, logger, device, cfg.train.model.model_name)

    if args.local_rank==0:
        torch.save({
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            # 'loss': criterion
        }, os.path.join(cfg.train.optimizer.save_path, cfg.train.model.model_name+'_'+cfg.train.dataloader.database+'_best_final.pt'))
        
        