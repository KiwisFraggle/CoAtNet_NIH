import os
import argparse
from re import T
from sched import scheduler
from tabnanny import verbose
import yaml
import time

from random import randint, choices
import random
from datetime import datetime
from math import log2

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import copy
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data.distributed import DistributedSampler
import torch.distributed

import torchvision
from torchvision import datasets, models, transforms
from torchvision.models import resnet101, vgg16_bn, efficientnet_b7, resnet18, resnet50, resnet152

from tensorboardX import SummaryWriter

from utils.utils import dict2namespace, read_config, set_seed, get_last_modified, set_seed_all
from utils.logger import create_logger_distribute
from utils import tb_utils
from dataloader.data_loader import YamlLoader
from model.coatnet import CoAtNet, coatnet_0, coatnet_1

from transformers import optimization
from utils.losses import GHM_loss, dice_loss_nlp, dice_loss, focal_loss, GHM_Loss, weight_ce_loss, BCE_loss

from torchstat import stat
# from utils.get_mean_std import get_mean_std



def train_multilabel(cfg, num_epochs, image_dataloader, model, criterion, optimizer, scheduler, writer, logger, device, model_name='CoAtNet'):
    last_loss = cfg.train.optimizer.epochs
    patience = cfg.train.optimizer.patience
    early_stopping = cfg.train.optimizer.early_stopping
    model_name = cfg.train.model.model_name
    trigger_times = 0

    # cfg.train.dataloader.dataset_sizes = dataset_sizes
    dataset_sizes = cfg.train.dataloader.dataset_sizes

    total_start = time.time()

    total_train_accuracy = []
    total_train_loss = []
    total_val_accuracy = []
    total_val_loss = []
    total_train_positive_accuracy = []
    total_val_positive_accuracy = []

    best_model_weight = copy.deepcopy(model.state_dict())
    best_acc = 0.0
    best_loss = float('inf')

    last_epoch = cfg.train.last_epoch
    for epoch in range(last_epoch, num_epochs):
        start = time.time()
        logger.info('Epoch {} / {}'.format(epoch, num_epochs-1))
        logger.info('-' * 20)
        
        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()
            else:
                model.eval()
            
            running_loss = 0.0
            running_corrects = 0
            positive_corrects = 0
            total_data = 0

            # total_data = 0
            #for inputs, labels in tqdm(image_dataloader[phase]):
            for index, (inputs, labels, file_name) in enumerate(tqdm(image_dataloader[phase])):
                inputs, labels = inputs.to(device).float(), labels.to(device).float()

                if phase == 'train':
                    outputs = model(inputs)
                else:
                    with torch.no_grad():
                        outputs = model(inputs)

                # print('inputs: {}; outputs: {}; labels: {}.'.format(inputs.shape, outputs.shape, labels.shape))
                # print('inputs: {}; outputs: {}; labels: {}.'.format(type(inputs), type(outputs), type(labels)))
                # print('inputs: {}; outputs: {}; labels: {}.'.format(inputs.dtype, outputs.dtype, labels.dtype))   

                # _, preds = torch.max(outputs, 1)
                preds = torch.round(torch.sigmoid(outputs))
                loss = criterion(outputs, labels)            

                if phase == 'train':
                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step() #按照batch来调整
                    
                    lr = optimizer.param_groups[0]['lr']
                    if cfg.train.local_rank == 0:
                        tb_utils.iter_scalar_metrics(writer, 'lr', lr, epoch * len(image_dataloader[phase]) + index)
                
            #     running_loss += loss.item() * inputs.size(0)
            #     # running_corrects += torch.sum(preds == labels.data)
            #     running_corrects += torch.sum(torch.eq(preds, labels).all(1))
            #     # total_data += inputs.shape[0]

            # if phase == 'train':
            #     scheduler.step() #按照周期来调整
            
            # # epoch_loss = running_loss / total_data
            # # epoch_accuracy = running_corrects.float() / total_data
            # epoch_loss = running_loss / dataset_sizes[phase]
            # epoch_accuracy = running_corrects.float() / dataset_sizes[phase]

            # if phase == 'train':
            #     total_train_loss.append(epoch_loss)
            #     total_train_accuracy.append(epoch_accuracy)
            # if phase == 'val':
            #     total_val_loss.append(epoch_loss)
            #     total_val_accuracy.append(epoch_accuracy)

                total_data += inputs.shape[0]
                running_loss += loss.item() * inputs.size(0)
                # running_corrects += torch.sum(torch.sum(torch.eq(preds , labels), 1)/ labels.shape[1]).item()
                running_corrects += torch.sum(torch.eq(preds, labels).all(1))
                positive_corrects += torch.sum(torch.sum(labels * preds, 1)/ torch.sum(labels, 1)).item()

            if phase == 'train':
                scheduler.step()
            
            epoch_loss = running_loss / total_data
            epoch_accuracy = running_corrects.float() / total_data
            positive_accuracy = positive_corrects / total_data

            if phase == 'train':
                total_train_loss.append(epoch_loss)
                total_train_accuracy.append(epoch_accuracy)
                total_train_positive_accuracy.append(positive_accuracy)
            if phase == 'val':
                total_val_loss.append(epoch_loss)
                total_val_accuracy.append(epoch_accuracy)
                total_train_positive_accuracy.append(positive_accuracy)

            logger.info('{} Loss: {:.5f} Accuracy: {:.5f} Positive_accuracy: {:.5f}'.format(phase, epoch_loss, epoch_accuracy, positive_accuracy))

            if phase == 'val' and epoch_accuracy > best_acc:
                best_acc = epoch_accuracy
                best_pos = positive_corrects
                best_loss = epoch_loss
                best_model_weight = copy.deepcopy(model.state_dict())

            if early_stopping and phase == 'val':
                if last_loss < epoch_loss:
                    trigger_times += 1
                    if trigger_times >= patience:
                        logger.info('Early stopping at epoch {}'.format(epoch))
                        total_time_elapsed = np.round(time.time() - total_start, 3)
                        logger.info('Completed training in {:0f}m {:03f}s'.format(total_time_elapsed // 60, total_time_elapsed % 60))
                        logger.info('Best Accuracy: {}, Best Loss: {}'.format(best_acc, best_loss))
                        model.load_state_dict(best_model_weight)
                        return model, total_train_accuracy, total_train_loss, total_val_accuracy, total_val_loss
                else:
                    trigger_times = 0
                last_loss = epoch_loss
        
        loss_dict = {
            "train": total_train_loss[-1],
            "val": total_val_loss[-1]
        }
        acc_dict = {
            "train": total_train_accuracy[-1],
            "val": total_val_accuracy[-1]
        }
        positive_acc_dict = {
            "train": total_train_positive_accuracy[-1],
            "val": total_train_positive_accuracy[-1]
        }        
        # if cfg.train.local_rank == 0:
        if writer is not None: 
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/loss', loss_dict, epoch)
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/acc', acc_dict, epoch)
            tb_utils.epoch_scalar_metrics(writer, 'Epoch/positive_acc', positive_acc_dict, epoch)            

        #save on every 10 epochs
        if epoch % cfg.train.optimizer.save_frequency == 0 and cfg.train.local_rank == 0:
            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': criterion,
                'epoch': epoch
            }, os.path.join(cfg.train.optimizer.save_path, '{}_{}_epoch_{}.pt'.format(model_name, cfg.train.dataloader.database, epoch)))
        
        end = np.round(time.time() - start, 3)
        logger.info('Epoch {}: {}s\n'.format(epoch, end))

    total_time_elapsed = np.round(time.time() - total_start, 3)
    logger.info('Completed training in {:0f}m {:03f}s'.format(total_time_elapsed // 60, total_time_elapsed % 60))
    logger.info('Best Accuracy: {}, Best Loss: {}'.format(best_acc, best_loss))

    model.load_state_dict(best_model_weight)
    return model, total_train_accuracy, total_train_loss, total_val_accuracy, total_val_loss

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="./config/FoodRecogition.yaml", type=str)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--local_rank", type=int, default=-1)
    parser.add_argument("--model", type=str, default="CoAtNet")
    args = parser.parse_args()

    cfg = dict2namespace(read_config(args.config))
    cfg.train.local_rank = args.local_rank

    torch.cuda.set_device(args.local_rank)
    device = torch.device('cuda', args.local_rank)
    if torch.distributed.is_nccl_available():
        torch.distributed.init_process_group(backend='nccl')
    else:
        torch.distributed.init_process_group(backend='gloo')
    # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    set_seed_all(cfg.seed)
    

    #create log
    log_name = args.config.split("/")[-1].split(".yaml")[0]
    log_path = cfg.train.optimizer.log_path
    if(not os.path.exists(log_path)) and args.local_rank == 0:
        os.makedirs(log_path)
    if(not os.path.exists(cfg.train.optimizer.save_path)) and args.local_rank == 0:
        os.makedirs(cfg.train.optimizer.save_path)
    logger, _, tensorboard_dir = create_logger_distribute(args, log_name, log_path)
    
    logger.info(torch.__version__)
    logger.info(torch.cuda.is_available())
    logger.info(cfg)
    logger.info("class_num: {}".format(len(cfg.train.dataloader.labels)))    

    ckpt = None
    cfg.train.last_epoch = 0
    if args.resume:
        logger.info("load ckpt...")
        ckpt = get_last_modified(cfg.train.optimizer.save_path)
        map_location = {'cuda:%d' % 0: 'cuda:%d' % args.local_rank}
        ckpt = torch.load(ckpt, map_location=map_location)
        cfg.train.last_epoch = ckpt["epoch"] + 1
        logger.info("load checkpoint from epoch {}".format(ckpt["epoch"]))
    
    #dataloader
    # mean, std = get_mean_std(cfg.train.dataloader.train_path, cfg.train.model.in_channels)
    mean = cfg.train.dataloader.normalize.mean
    std = cfg.train.dataloader.normalize.std
    data_transforms = {
    'train': transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(degrees=10),
        transforms.Resize(cfg.train.dataloader.resize[1:]),
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ]),
    'val': transforms.Compose([
        transforms.Resize(cfg.train.dataloader.resize[1:]),
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ])
}
    data_yaml = {
        'train': cfg.train.dataloader.train_path,
        'val': cfg.train.dataloader.val_path
    }

    # # 二分类使用，用于计算权重    
    # if len(cfg.train.dataloader.labels)==2:
    #     i,j=0,0
    #     for image, label, file_name in tqdm(YamlLoader(cfg, data_yaml['train'])):
    #         if label==0:
    #             i+=1
    #         elif label==1:
    #             j+=1
    # assert(len(cfg.train.dataloader.labels)==2)

    image_datasets = {x: YamlLoader(cfg, data_yaml[x], data_transforms[x]) for x in ['train', 'val']}
    image_sampler = {x: DistributedSampler(image_datasets[x]) for x in ['train', 'val']}
    image_dataloader = {x: torch.utils.data.DataLoader(image_datasets[x], \
        batch_size=cfg.train.dataloader.batch_size, \
        num_workers=cfg.train.dataloader.num_workers,
        sampler=image_sampler[x]) \
        for x in ['train', 'val']}

    dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'val']}
    cfg.train.dataloader.dataset_sizes = dataset_sizes

    class_names = image_datasets['train'].classes

    #models
    model = coatnet_0(cfg.train.model.in_channels, cfg.train.model.num_classes, cfg.train.dataloader.resize[1:])

    # model = resnet50(pretrained=True)
    # model.conv1 = nn.Conv2d(cfg.train.model.in_channels, 64, kernel_size=7, stride=2, padding=3,
    #                            bias=False)
    # model.fc = nn.Linear(model.fc.in_features, cfg.train.model.num_classes)
    # print(model)
    # stat(model, cfg.train.dataloader.resize)
    # total = sum([param.nelement() for param in model.parameters()])
    # print("Number of parameters: %.2fM" % (total/1e6))


    model.to(device)
    model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.local_rank], output_device=args.local_rank, find_unused_parameters=False)
    if ckpt is not None:
        model.load_state_dict(ckpt["model_state_dict"])

    #optimizer
    if isinstance(model,torch.nn.parallel.DistributedDataParallel):
        train_params = model.module.parameters() 
    else:
        train_params = model.parameters()
    # optimizer = optim.SGD(train_params, lr=cfg.train.optimizer.lr, momentum=0.9)
    optimizer = optim.AdamW(train_params, lr=cfg.train.optimizer.lr)
    if ckpt is not None:
        optimizer.load_state_dict(ckpt["optimizer_state_dict"])
    
    #scheduler
    # scheduler = lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=5, T_mult=2, verbose=True)
    # scheduler = lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)
    # scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=5)
    # scheduler = optimization.get_cosine_with_hard_restarts_schedule_with_warmup(
    #     optimizer, 
    #     num_warmup_steps=10, 
    #     num_training_steps=cfg.train.optimizer.epochs, 
    #     num_cycles=2)    
    scheduler = optimization.get_linear_schedule_with_warmup(
        optimizer, 
        num_warmup_steps=10,
        num_training_steps=cfg.train.optimizer.epochs
    )
    # scheduler = lr_scheduler.OneCycleLR(optimizer, 
    #                                     max_lr=cfg.train.optimizer.lr,
    #                                     steps_per_epoch=len(image_dataloader['train']),
    #                                     epochs=cfg.train.optimizer.epochs,
    #                                     pct_start=0.2)    
    

    # criterion = nn.CrossEntropyLoss()
    # criterion = nn.CrossEntropyLoss(weight=torch.FloatTensor([j/i,1]).cuda())
    # criterion = focal_loss.FocalLoss(num_class=2, alpha=[0.75, 0.25])
    # criterion = weight_ce_loss.WBCEWithLogitLoss()
    # criterion = nn.CrossEntropyLoss(weight=torch.FloatTensor([0.025, 0.975]).cuda(), size_average=True, label_smoothing=1e-5)
    # criterion = focal_loss.FocalLoss(num_class=2, alpha=[0.025, 0.975], gamma=2)
    # criterion = nn.CrossEntropyLoss(weight=torch.FloatTensor([0.462, 0.538]).cuda(), size_average=True, label_smoothing=1e-5)
    # criterion = nn.CrossEntropyLoss(
    #     weight=torch.FloatTensor([0.6610, 0.1045, 0.0462, 0.0433, 0.0296, 0.0240, 0.0234, 0.0143, 0.0123, 0.0120, 0.0098, 0.0080, 0.0069, 0.0035, 0.0012]).cuda(), 
    #     size_average=True, 
    #     label_smoothing=1e-5
    # )
    # criterion = nn.BCEWithLogitsLoss(pos_weight=torch.FloatTensor([0.461835533, 0.822574028, 0.896905102, 0.881278987, 0.943542633, 0.952747057, 0.948448091, 0.958392793, 0.969826971, 0.975276489, 0.977604352, 0.98496254, 0.979459508, 0.987245808]).cuda(), size_average=True)
    # criterion = nn.BCEWithLogitsLoss(size_average=True)
    # criterion = lambda x,y : dice_loss.MultilabelDiceLoss()(x, y) + BCE_loss.BinaryCELoss()(x, y)
    # criterion = nn.MultiLabelMarginLoss()
    # criterion = nn.BCEWithLogitsLoss(pos_weight=torch.FloatTensor([0.858168016, 4.636153426, 8.699801051, 7.423108721, 16.71248029, 20.16270303, 18.39792375, 23.03429771, 32.14218138, 39.44732967, 43.6515323, 65.50059252, 47.68432558, 77.40559402]).cuda(), size_average=True)
    # pos_weight = torch.FloatTensor([4.6, 8.7, 7.4, 16.7]).cuda()
    pos_weight = torch.FloatTensor([4.6, 8.7, 7.4, 16.7, 20.2, 18.4, 23.0, 32.1, 39.4, 43.7, 65.5, 47.7, 77.4]).cuda()
    # pos_weight = torch.FloatTensor([1.6, 3.5, 2.9, 7.2, 8.7, 7.9, 10.1, 14.3, 17.6, 19.5, 29.6, 21.4, 35.1]).cuda()
    # pos_weight = torch.FloatTensor([1.6, 2.9, 8.7, 17.6]).cuda()
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight, reduction='mean')
    # criterion = nn.BCEWithLogitsLoss(reduction='mean')
    # criterion = BCE_loss.BinaryCELoss()

    # weight=torch.FloatTensor([0.018, 0.021, 0.028, 0.031, 0.034, 0.042, 0.058, 0.065, 0.071, 0.078, 0.143, 0.164, 0.246]).cuda()
    # criterion = nn.CrossEntropyLoss(
    #     reduction='sum', 
    #     label_smoothing=1e-5
    # )
    


    if args.local_rank == 0:
        writer = SummaryWriter(tensorboard_dir)
    else:
        writer = None

    #train
    train_multilabel(cfg, cfg.train.optimizer.epochs, image_dataloader, model, criterion, optimizer, scheduler, writer, logger, device, cfg.train.model.model_name)

    if args.local_rank==0:
        torch.save({
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'loss': criterion
        }, os.path.join(cfg.train.optimizer.save_path, cfg.train.model.model_name+'_'+cfg.train.dataloader.database+'_best_final.pt'))
        
        

