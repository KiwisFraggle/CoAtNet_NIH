import os
# os.environ["CUDA_VISIBLE_DEVICES"]="3"
import cv2
import numpy as np
from matplotlib import pyplot as plt
from tqdm import tqdm
import argparse

import torch
from torch import nn
import torch.nn.functional as F

from torchvision import transforms

from utils.gradcam import GradCAM, GroupCAM, ScoreCAM
from utils.gradcam.utils import preprocess_img, show_heatmap, show_cam
from utils.utils import dict2namespace, read_config
from dataloader.data_loader import YamlLoader

from torchvision.models import resnet50
from timm.models.maxxvit import coatnet_0_rw_224

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="./config/NIH_c13.yaml", type=str)
    parser.add_argument("--save_path", default="./gcam_result", type=str)
    args = parser.parse_args()

    cfg = dict2namespace(read_config(args.config))
    cfg.inference.dataloader.batch_size = 1

    # make save path
    if not os.path.exists(args.save_path):
        os.makedirs(args.save_path)
    for label_name in cfg.train.dataloader.labels:
        path = os.path.join(args.save_path, label_name)
        if not os.path.exists(path):
            os.makedirs(path)


    # prepare_data
    mean = cfg.train.dataloader.normalize.mean
    std = cfg.train.dataloader.normalize.std
    data_transforms = {
    'test': transforms.Compose([
        transforms.Resize(cfg.train.dataloader.resize[1:]),
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ]),
    }
    
    data_yaml = {
        'test': cfg.inference.dataloader.test_path,
    }
    image_datasets = {x: YamlLoader(cfg, data_yaml[x], data_transforms[x]) for x in ['test']}
    image_dataloader = {x: torch.utils.data.DataLoader(image_datasets[x], \
        batch_size=cfg.inference.dataloader.batch_size, \
        shuffle=False, \
        num_workers=cfg.inference.dataloader.num_workers) \
        for x in ['test']}
    
    # model = resnet50(pretrained=True).cuda()
    model = coatnet_0_rw_224(pretrained=False, in_chans=cfg.train.model.in_channels, num_classes=cfg.train.model.num_classes,).cuda()
    for layer_name in model.named_modules():
        print(layer_name)
    model = nn.DataParallel(model)

    #load state dict
    ckpt = cfg.inference.model.checkpoint
    ckpt = torch.load(ckpt)
    model.load_state_dict(ckpt["model_state_dict"])

    model.eval()
    # gc = GradCAM(model, target_layer="layer4") # resnet
    gc = GradCAM(model, target_layer="module.stages.3") # coatnet


    for i, (norm_image, label, file_name) in enumerate(tqdm(image_dataloader["test"])):
        heatmap = gc(norm_image.cuda(), class_idx=None).cpu().data
        image = norm_image * std[0] + mean[0]
        cam = show_cam(image, heatmap).squeeze().permute(1, 2, 0).numpy()

        # save
        file_name = os.path.basename(file_name[0])
        label_names = cfg.train.dataloader.labels
        label_idx = label.squeeze().cpu().numpy()
        label_names = [label_names[x] for x in np.where(label_idx > 0)[0]]

        for l in label_names:
            path = os.path.join(args.save_path, l, file_name)
            cv2.imwrite(path, cam*255)
