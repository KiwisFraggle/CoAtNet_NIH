import sys
import os
root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-2])
sys.path.append(root_path)

import yaml 
import argparse
import random

from utils.utils import load_yaml, save_yaml

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("yaml_path", type=str)
    parser.add_argument("--split", type=int, default=[0.7,0.2,0.1], nargs='+')

    args = parser.parse_args()
    
    yaml_dict = load_yaml(args.yaml_path)
    data = yaml_dict["data"]
    random.shuffle(data)

    train_num = int(len(data)*args.split[0])
    val_num = int(len(data)*args.split[1])
    test_num = int(len(data)*args.split[2])

    train_data = data[:train_num]
    val_data = data[train_num : train_num+val_num]
    test_data = data[train_num+val_num:]

    train_yaml = args.yaml_path.replace(".yaml", "_train.yaml")
    val_yaml = args.yaml_path.replace(".yaml", "_val.yaml")
    test_yaml = args.yaml_path.replace(".yaml", "_test.yaml")

    train_dict = {
        "data": train_data,
        "total_num": len(train_data),
        "root_dir": yaml_dict["root_dir"]
    }
    val_dict = {
        "data": val_data,
        "total_num": len(val_data),
        "root_dir": yaml_dict["root_dir"]
    }
    test_dict = {
        "data": test_data,
        "total_num": len(test_data),
        "root_dir": yaml_dict["root_dir"]
    }

    save_yaml(train_dict, train_yaml)
    save_yaml(val_dict, val_yaml)
    save_yaml(test_dict, test_yaml)