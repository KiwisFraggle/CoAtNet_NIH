import sys
import os
import numpy as np
root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-2])
sys.path.append(root_path)

import yaml
from utils.utils import load_yaml


if __name__ == '__main__':
    yaml_dict = load_yaml("./data/yaml/NIH/NIH_c13_train.yaml")

    class_names = []
    for data in yaml_dict["data"]:
        class_names += data['label']
    
    class_names_set = ['Effusion', 'Nodule', 'Atelectasis', 'Consolidation', 'Emphysema', 'Pneumonia', 'Cardiomegaly', 'Pneumothorax', 'Edema', 'Infiltration', 'Fibrosis', 'Mass', 'Pleural_Thickening']#set(class_names)

    class_names_count = np.zeros(len(class_names_set))
    for i, name in enumerate(class_names_set):
        class_names_count[i] = class_names.count(name)


    print(class_names_set) 
    # print(class_names_count)
    # print(np.min(class_names_count))
    print(np.max(class_names_count)/class_names_count)