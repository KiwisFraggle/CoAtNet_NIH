import sys
import os
root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-2])
sys.path.append(root_path)

import PIL
import yaml

import torch
from torch.utils.data import Dataset
import numpy as np

from utils.utils import load_yaml

class YamlLoader(Dataset):
    def __init__(self, cfg, path, transform=None):
        data_dict = load_yaml(path)
        self.data = data_dict['data']
        self.root_dir = data_dict["root_dir"]
        self.cfg = cfg
        self.transform = transform
        self.classes = cfg.train.dataloader.labels

    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, index):
        data = self.data[index]
        image = PIL.Image.open(os.path.join(self.root_dir, data["path"]))
        if self.cfg.train.dataloader.resize[0] == 1:
            image = image.convert('L')# some images are 32bit, different from others' 8bit

        label = data["label"]

        if isinstance(label, list):
            # label = label[0]
            labels = label
            label = np.zeros(len(self.classes))
            for lb in labels:
                if lb in self.classes:
                    label[self.classes.index(lb)] = 1
                
        elif label in self.classes:
            # label = self.classes.index(label)
            label_idx = self.classes.index(label)
            label = np.zeros(len(self.classes))
            label[label_idx] = 1
        file_name = data["file_name"]

        if self.transform is not None:
            image = self.transform(image)
        
        return image, label, file_name
