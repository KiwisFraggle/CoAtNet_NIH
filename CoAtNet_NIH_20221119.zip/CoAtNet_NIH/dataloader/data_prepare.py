#save data infos to yaml
import sys
import os
root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-2])
sys.path.append(root_path)

import pandas as pd
import yaml
import argparse
from tqdm import tqdm

from utils.utils import load_yaml, save_yaml

#need to rewrite according to different datasets
def read_csv(args):
    path = args.csv_path
    file_tag = args.file_tag
    label_tag = args.label_tag

    csv = pd.read_csv(path)
    labels = csv[label_tag].to_list()
    file_names = csv[file_tag].to_list()

    return file_names, labels

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("data_path", type=str)
    parser.add_argument("csv_path", type=str)
    parser.add_argument("--save_path", type=str, default=None)
    parser.add_argument("--file_tag", type=str, default="file")
    parser.add_argument("--label_tag", type=str, default="label")
    parser.add_argument("--multi_label", action="store_true")
    parser.add_argument("--root_dir", type=str, default="")

    args = parser.parse_args()

    data_path = os.path.abspath(args.data_path)
    root_dir = os.path.abspath(args.root_dir)
        
    if not args.save_path:
        args.save_path = os.path.join(data_path, args.csv_path.split("/")[-1].split(".csv")[0] + ".yaml")
    elif not os.path.exists(os.path.dirname(args.save_path)):
        print("create save path: {}".format(os.path.dirname(args.save_path)))
        os.makedirs(os.path.dirname(args.save_path))
    
    file_names, labels = read_csv(args)

    print("total_num: ", len(file_names))

    data = []
    for root, dir, files in os.walk(data_path):
        print(root)
        for file in tqdm(files):
            if file in file_names:
                file_dir = os.path.join(root, file)
                label = labels[file_names.index(file)]
                if args.multi_label:
                    label = label.split("|")

                data_dict = {
                    "file_name": file,
                    "label": label,
                    "path" : file_dir.split(root_dir)[-1]
                }
                data.append(data_dict)
    
    print("saving...")
    yaml_dict = {
            "data": data,
            "total_num": len(data),
            "root_dir": root_dir
        }
    save_yaml(yaml_dict, args.save_path)