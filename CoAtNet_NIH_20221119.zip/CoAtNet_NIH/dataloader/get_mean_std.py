import sys
import cv2
import numpy as np
import argparse
import os
from tqdm import tqdm

root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-2])
sys.path.append(root_path)

from utils.utils import load_yaml

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="./data/Training_set_food.yaml", type=str)
    parser.add_argument("--channel", default = 3, type=int)

    args = parser.parse_args()

    assert args.channel in [1, 3]
    data_dict = load_yaml(args.data)
    data = data_dict['data']
    # data = data[:1000]
    root_dir = data_dict['root_dir']

    mean_all = np.zeros(args.channel)
    std_all = np.zeros(args.channel)

    for d in tqdm(data):
        file_path = d['path']
        
        if args.channel == 3:
            imread_arg = cv2.IMREAD_COLOR
        else:
            imread_arg = cv2.IMREAD_GRAYSCALE
        image = cv2.imread(os.path.join(root_dir, file_path), imread_arg).astype(np.float32) / 255
        if len(image.shape) == 2:
            image = np.expand_dims(image, axis=-1)

        mean = np.zeros(args.channel)
        std = np.zeros(args.channel)
        for i in range(args.channel):
            mean[i] = image[:, :, i].mean()
            std[i] = image[:, :, i].std()

        mean_all += mean
        std_all += std

    print(mean_all / len(data))
    print(std_all / len(data))



