import os
import sys
root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-2])
sys.path.append(root_path)

from utils.utils import load_yaml, save_yaml
from random import shuffle

if __name__ == '__main__':
    yaml_dict = load_yaml("../data/yaml/NIH/NIH.yaml")
    data= yaml_dict["data"]
    shuffle(data)
    # data = data[:1000]

    sample_data = []
    # while len(sample_data) < 1000:
    for d in data:
        if len(sample_data) > 500000:
            break
        if "No Finding" in d['label'] or "Hernia" in d['label']:
            continue
        sample_data.append(d)
    
    sample_dict = {
        "data": sample_data,
        "root_dir": "",
        'total_num' : len(sample_data)
    }

    save_yaml(sample_dict, "../data/yaml/NIH/NIH_c13.yaml")
