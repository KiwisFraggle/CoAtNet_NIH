'''
get class frequency, save to yaml file.
the frequency will be used in resample loss.
'''
import sys
import os
root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-2])
sys.path.append(root_path)

import numpy as np
import argparse
from utils.utils import load_yaml, save_yaml

def get_class_frequency(data_yaml, config_yaml):
    
    data_dict = load_yaml(data_yaml)
    data = data_dict["data"]
    config_dict = load_yaml(config_yaml)
    gt_label_names = config_dict["train"]["dataloader"]["labels"]
    gt_label_stat = np.zeros(len(gt_label_names), dtype=np.int32)

    for d in data:
        label = d["label"]
        if isinstance(label, list):
            for l in label:
                if l in gt_label_names:
                    idx = gt_label_names.index(l)
                    gt_label_stat[idx] += 1
        elif isinstance(label, str):
                if l in gt_label_names:
                    idx = gt_label_names.index(l)
                    gt_label_stat[idx] += 1
    
    class_freq = gt_label_stat
    neg_class_freq = len(data) - class_freq

    config_dict["train"]["dataloader"]["class_freq"] = class_freq.tolist()
    config_dict["train"]["dataloader"]["neg_class_freq"] = neg_class_freq.tolist()
    
    save_yaml(config_dict, config_yaml)

    return class_freq, neg_class_freq

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="./data/yaml/NIH/NIH_c13.yaml", type=str)
    parser.add_argument("--config", default="./config/NIH_c13.yaml", type=str)
    args = parser.parse_args()

    class_freq, neg_class_freq = get_class_frequency(args.data, args.config)
    print("class freq: ", class_freq)
    print("neg class freq: ", neg_class_freq)


