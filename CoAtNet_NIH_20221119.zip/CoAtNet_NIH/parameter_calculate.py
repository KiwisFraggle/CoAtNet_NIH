# -- coding: utf-8 --
import torch
import torchvision
from thop import profile
from model.coatnet import CoAtNet, coatnet_0, coatnet_1
from timm.models.maxxvit import coatnet_0_rw_224, coatnet_bn_0_rw_224, coatnet_0_224

# If meet AttributeError: 'LayerNorm' object has no attribute 'affine', pip install thop==0.0.31-2005241907.

# Model
if __name__ == '__main__':
    print('==> Building model..')
    model = torchvision.models.resnet50(pretrained=False)

    dummy_input = torch.randn(1, 3, 224, 224)
    flops, params = profile(model, (dummy_input,))
    # print(model)
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f M, params: %.2f M' % (flops / 1000000.0, params / 1000000.0))


    print('==> Building model..')
    model = torchvision.models.resnet101(pretrained=False)

    dummy_input = torch.randn(1, 3, 224, 224)
    flops, params = profile(model, (dummy_input,))
    # print(model)
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f M, params: %.2f M' % (flops / 1000000.0, params / 1000000.0))


    print('==> Building model..')
    model = torchvision.models.vgg11(pretrained=False)

    dummy_input = torch.randn(1, 3, 224, 224)
    # print(model)
    flops, params = profile(model, (dummy_input,))
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f M, params: %.2f M' % (flops / 1000000.0, params / 1000000.0))


    print('==> Building model..')
    model = torchvision.models.efficientnet_b5(pretrained=False)

    dummy_input = torch.randn(1, 3, 224, 224)
    flops, params = profile(model, (dummy_input,))
    # print(model)
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f M, params: %.2f M' % (flops / 1000000.0, params / 1000000.0))


    print('==> Building model..')
    model = torchvision.models.vit_b_16(pretrained=False)

    dummy_input = torch.randn(1, 3, 224, 224)
    flops, params = profile(model, (dummy_input,))
    print(model)
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f M, params: %.2f M' % (flops / 1000000.0, params / 1000000.0))


    print('==> Building model..')
    model = coatnet_bn_0_rw_224(pretrained=False)

    dummy_input = torch.randn(1, 3, 224, 224)
    flops, params = profile(model, (dummy_input,))
    # print(model)
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f M, params: %.2f M' % (flops / 1000000.0, params / 1000000.0))


    print('==> Building model..')
    model = coatnet_0_rw_224(pretrained=False)

    dummy_input = torch.randn(1, 3, 224, 224)
    flops, params = profile(model, (dummy_input,))
    # print(model)
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f M, params: %.2f M' % (flops / 1000000.0, params / 1000000.0))


    print('==> Building model..')
    model = coatnet_0_224(pretrained=False)

    dummy_input = torch.randn(1, 3, 224, 224)
    flops, params = profile(model, (dummy_input,))
    # print(model)
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f M, params: %.2f M' % (flops / 1000000.0, params / 1000000.0))