#!/bin/sh

python ./dataloader/data_prepare.py ./data/NIH ./data/NIH/Data_Entry_2017.csv --save_path ./data/yaml/NIH/NIH.yaml --file_tag "Image Index" --label_tag "Finding Labels" --multi_label