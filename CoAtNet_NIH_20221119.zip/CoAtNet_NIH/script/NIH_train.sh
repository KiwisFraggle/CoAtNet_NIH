#!/bin/sh

python train.py --config ./config/NIH.yaml 