#!/bin/sh

python -m torch.distributed.launch --nproc_per_node=2 --nnodes=1 train_distributed.py --config config/NIH_1000.yaml