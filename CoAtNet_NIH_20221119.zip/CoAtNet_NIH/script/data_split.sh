#!/bin/sh

python ./dataloader/data_split.py ./data/yaml/NIH/NIH.yaml