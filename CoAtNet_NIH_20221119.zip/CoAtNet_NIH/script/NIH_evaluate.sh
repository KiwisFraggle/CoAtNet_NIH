#!/bin/sh

python evaluate.py --config ./config/NIH.yaml 