from functools import partial
import os
import argparse
from turtle import shape
import yaml
import time

from random import randint, choices
import random
from datetime import datetime
from math import log2
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import copy
from tqdm import tqdm
from sklearn import metrics

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.optim import lr_scheduler

import torchvision
from torchvision import datasets, models, transforms

from tensorboardX import SummaryWriter

from utils.utils import dict2namespace, read_config, set_seed, get_last_modified
from utils.logger import create_logger
from utils import tb_utils
from dataloader.data_loader import YamlLoader
from model.coatnet import CoAtNet, coatnet_0, coatnet_1
from timm.models.maxxvit import coatnet_0_rw_224, coatnet_bn_0_rw_224

from collections import OrderedDict
from torchvision.ops.misc import ConvNormActivation, SqueezeExcitation


def evaluate_multilabel(cfg, image_dataloader, model, logger, device):

    #create csv
    csv_path = os.path.dirname(cfg.inference.output.save_csv)
    if not os.path.exists(csv_path):
        os.makedirs(csv_path)
    df = pd.DataFrame()

    titles = ["filename",] + cfg.train.dataloader.labels    
    # df.loc[0] = titles

    total_corrects = 0
    per_class_correct = np.zeros(len(cfg.train.dataloader.labels), dtype=int)
    per_class_positive_sample = np.zeros(len(cfg.train.dataloader.labels), dtype=int)
    total_images_processed = 0
    total_label = None
    total_label_prob = None
    total_preds = None

    model.eval()
    
    start = time.time()
    with torch.no_grad():
        for i, data in enumerate(tqdm(image_dataloader['test'])):
            inputs, labels, filenames = data[0].to(device), data[1].to(device), data[2]

            outputs = model(inputs) #[batch, classes]
            # outputs = F.softmax(outputs, dim=1)
            # _, preds = torch.max(outputs, 1)

            outputs = torch.sigmoid(outputs)

            preds = torch.round(outputs) #[B, C]

            if total_label is not None:
                total_label = torch.concat([total_label, labels], dim=0)
            else:
                total_label = labels
            
            label_probs = outputs
            if total_label_prob is not None:
                total_label_prob = torch.concat([total_label_prob, label_probs], dim=0)
            else:
                total_label_prob = label_probs

            if total_preds is not None:
                total_preds = torch.concat([total_preds, preds], dim=0)
            else:
                total_preds = preds

            for j in range(inputs.size()[0]):
                total_images_processed += 1
                
                if (preds[j] == labels[j]).all():
                    total_corrects += 1
                
                per_class_correct += (preds[j] == labels[j]).cpu().numpy()
                per_class_positive_sample += (labels[j] == 1).cpu().numpy()

                output_list = outputs[j].detach().cpu().tolist()
                save_data = [[filenames[j]] + output_list]

                df_new = pd.DataFrame(save_data, columns=titles)
                df = pd.concat([df, df_new], axis=0, join='outer')

    end = np.round(time.time() - start, 4)
    time_per_image = np.round(end / total_images_processed, 4)
    total_accuracy = np.round(total_corrects / total_images_processed, 4)
    per_class_accuracy = np.round(per_class_correct / total_images_processed, 4)

    total_label= total_label.detach().cpu().numpy()
    total_label_prob = total_label_prob.detach().cpu().numpy()
    total_preds = total_preds.detach().cpu().numpy()

    # total_label = np.delete(total_label, 12, 1)
    # total_label_prob = np.delete(total_label_prob, 13, 1)
    # total_label = np.delete(total_label, 5, 1)
    # total_label_prob = np.delete(total_label_prob, 5, 1)

    # print("num per class: ", total_label.sum(0))

    #see more info: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.roc_auc_score.html
    roc_auc = metrics.roc_auc_score(total_label, total_label_prob, multi_class='ovr')

    per_class_roc_auc = []
    per_class_report = []
    for i in range(len(cfg.train.dataloader.labels)):
        try:
            per_class_roc_auc.append(metrics.roc_auc_score(total_label[:, i], total_label_prob[:, i]))
        except:
            per_class_roc_auc.append(-1)

    df.to_csv(cfg.inference.output.save_csv, index=None)

    logger.info('Test Accuracy: {} / {} = {}'.format(total_corrects, total_images_processed, total_accuracy))    
    logger.info('Test roc_auc_score: {}'.format(roc_auc))
    logger.info('Total time elapsed: {}'.format(end))
    logger.info('Time elapsed per image: {}'.format(time_per_image))
    for i, label_name in enumerate(cfg.train.dataloader.labels):
        logger.info("{}:".format(label_name))
        logger.info("\tpositive sample num: {}".format(per_class_positive_sample[i]))
        logger.info('\tTest Accuracy: {} / {} : {}'.format(per_class_correct[i], total_images_processed, per_class_accuracy[i]))
        logger.info('\tTest roc_auc_score: {}'.format(np.round(per_class_roc_auc[i], 4)))
        logger.info('\nTest report of {}: \n{}'.format(label_name, metrics.classification_report(total_label[:, i], total_preds[:, i], labels=[0,1])))
        # print("***************************************************\n", metrics.classification_report(total_label[:, i], total_preds[:, i], labels=[0,1]))
    return total_accuracy, roc_auc



if __name__ == '__main__':
    #init
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="./config/FoodRecogition.yaml", type=str)
    parser.add_argument("--model_path", default="F:\CoAtNet_NIH\ckpt\CoAtNet_0_NIH_Cardiomegaly_best_final.pt", type=str)
    args = parser.parse_args()
    
    cfg = dict2namespace(read_config(args.config))

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    set_seed(cfg.seed)
    
    #log
    log_name = args.config.split("/")[-1].split(".yaml")[0]
    log_path = cfg.train.optimizer.log_path
    if(not os.path.exists(log_path)):
        os.makedirs(log_path)
    if(not os.path.exists(cfg.train.optimizer.save_path)):
        os.makedirs(cfg.train.optimizer.save_path)
    logger, _, tensorboard_dir = create_logger(cfg, log_name, log_path, phase="test")
    
    logger.info(torch.__version__)
    logger.info(torch.cuda.is_available())
    logger.info(cfg)
    
    #dataset
    mean = cfg.train.dataloader.normalize.mean
    std = cfg.train.dataloader.normalize.std
    data_transforms = {
    'test': transforms.Compose([
        transforms.Resize(cfg.train.dataloader.resize[1:]),
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ]),
    }
    
    data_yaml = {
        'test': cfg.inference.dataloader.test_path,
    }
    image_datasets = {x: YamlLoader(cfg, data_yaml[x], data_transforms[x]) for x in ['test']}
    image_dataloader = {x: torch.utils.data.DataLoader(image_datasets[x], \
        batch_size=cfg.inference.dataloader.batch_size, \
        shuffle=False, \
        num_workers=cfg.inference.dataloader.num_workers) \
        for x in ['test']}
    
    dataset_sizes = {x: len(image_datasets[x]) for x in ['test']}
    cfg.train.dataloader.dataset_sizes = dataset_sizes

    class_names = image_datasets['test'].classes

    #model
    # model = coatnet_0_rw_224(pretrained=False, in_chans=cfg.train.model.in_channels, num_classes=cfg.train.model.num_classes)
    # model = coatnet_bn_0_rw_224(pretrained=False, in_chans=cfg.train.model.in_channels, num_classes=cfg.train.model.num_classes)

    model = torchvision.models.resnet50(pretrained=False)
    model.conv1 = nn.Conv2d(cfg.train.model.in_channels, 64, kernel_size=7, stride=2, padding=3, bias=False)
    model.fc = nn.Sequential(
        nn.Dropout(p=0.0), 
        nn.Linear(model.fc.in_features, cfg.train.model.num_classes))


    # model = torchvision.models.vit_b_16(pretrained=True)
    # model.conv_proj = nn.Conv2d(cfg.train.model.in_channels, 768, kernel_size=(16, 16), stride=(16, 16))
    # model.heads.head = nn.Sequential(
    #     nn.Dropout(p=0.0, inplace=True),
    #     nn.Linear(in_features=768, out_features=cfg.train.model.num_classes, bias=True))

    # model = torchvision.models.efficientnet_b5(pretrained=False)
    # model.features[0] = ConvNormActivation(
    #     in_channels=1, 
    #     out_channels=48,
    #     kernel_size=3,
    #     stride=2,
    #     norm_layer=partial(nn.BatchNorm2d, eps=0.001, momentum=0.01),
    #     activation_layer=nn.SiLU)
    # model.classifier = nn.Sequential(
    #     nn.Dropout(p=0.0),
    #     nn.Linear(in_features=2048, out_features=cfg.train.model.num_classes, bias=True))

    if torch.cuda.is_available() and torch.cuda.device_count () > 1:
        model = nn.DataParallel(model)  #此种情况是模型在DataParallel或者DDP训练后保存的键值前面加有module. ，对应的网络的键值则没有module，因此需要此命令将模型的键值加上module。
    else:
        model = nn.DataParallel(model)
    model.to(device)

    logger.info("load ckpt from {}".format(args.model_path))
    ckpt = args.model_path
    if torch.cuda.is_available():
        # ckpt = torch.load(ckpt, map_location='cuda') # single GPU
        ckpt = torch.load(ckpt)
    else:
        ckpt = torch.load(ckpt, map_location='cpu') 
    
    model.load_state_dict(ckpt["model_state_dict"])
    
    #evaluate
    acc, roc_auc = evaluate_multilabel(cfg, image_dataloader, model, logger, device)